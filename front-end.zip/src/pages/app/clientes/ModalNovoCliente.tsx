import React, { useState, useEffect } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { ClientesService } from '@/api/clientes'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { toast } from 'sonner'
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogTitle,
  DialogDescription,
  DialogClose
} from '@radix-ui/react-dialog'
import { X } from 'lucide-react'

/**
 * Modal para criação de novo cliente principal.
 * - Abre diálogo para inserir nome da empresa.
 * - Cria cliente via API e atualiza lista.
 * - Inclui rótulo, botão de fechar e validações.
 */
export function ModalNovoCliente() {
  const [open, setOpen] = useState(false)
  const [nomeEmpresa, setNomeEmpresa] = useState('')
  const queryClient = useQueryClient()

  // Resetar campo ao abrir modal
  useEffect(() => {
    if (open) setNomeEmpresa('')
  }, [open])

  // Mutação para criar cliente
  const mutation = useMutation({
    mutationFn: () =>
      ClientesService.criar({ nomeEmpresa: nomeEmpresa.trim(), clientePaiId: null }),
    onSuccess: () => {
      toast.success('Cliente criado com sucesso!')
      queryClient.invalidateQueries(['clientes'])
      setOpen(false)
    },
    onError: (error: any) => {
      const msg = error?.response?.data?.error || 'Erro ao criar cliente.'
      toast.error(msg)
    }
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!nomeEmpresa.trim()) {
      toast.error('O nome da empresa é obrigatório.')
      return
    }
    mutation.mutate()
  }

  return (
    <Dialog
      open={open}
      onOpenChange={setOpen}
    >
      <DialogTrigger asChild>
        <Button>+ Adicionar Cliente</Button>
      </DialogTrigger>

      <DialogContent className="max-w-md">
        <div className="flex justify-between items-center mb-4">
          <DialogTitle>Novo Cliente</DialogTitle>
          <DialogClose asChild>
            <button aria-label="Fechar">
              <X className="w-5 h-5" />
            </button>
          </DialogClose>
        </div>

        <DialogDescription className="mb-4">
          Insira o nome da empresa para cadastro.
        </DialogDescription>

        <form
          onSubmit={handleSubmit}
          className="space-y-4"
        >
          <label
            htmlFor="nomeEmpresa"
            className="block text-sm font-medium"
          >
            Nome da Empresa
          </label>
          <Input
            id="nomeEmpresa"
            name="nomeEmpresa"
            placeholder="Digite o nome"
            value={nomeEmpresa}
            onChange={(e) => setNomeEmpresa(e.target.value)}
            required
            disabled={mutation.isLoading}
          />

          <div className="flex justify-end space-x-2">
            <Button
              type="button"
              variant="secondary"
              onClick={() => setOpen(false)}
              disabled={mutation.isLoading}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={mutation.isLoading || !nomeEmpresa.trim()}
            >
              {mutation.isLoading ? 'Criando...' : 'Criar'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
