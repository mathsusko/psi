import React, { useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell
} from '@/components/ui/table'
import { MoveLeft, Trash } from 'lucide-react'
import { toast } from 'sonner'
import { useFiliais, useDeletarFilial } from '@/hooks/useFiliais'
import { useCliente } from '@/hooks/useCliente'
import { ModalNovaFilial } from './ModalNovaFilial'

export default function FiliaisDoCliente() {
  const { clienteId } = useParams<{ clienteId: string }>()
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)

  // Carregar dados do cliente
  const {
    data: cliente,
    isLoading: clienteLoading,
    isError: clienteError
  } = useCliente(clienteId!)

  // Carregar as filiais do cliente
  const { data: filiais = [], isLoading, isError, refetch } = useFiliais(clienteId!)
  const delMutation = useDeletarFilial()

  // Tratamento de erro e loading para o cliente
  if (clienteLoading) return <div>Carregando cliente...</div>
  if (clienteError || !cliente) return <div>Erro ao carregar cliente.</div>

  // Tratamento de erro e loading para as filiais
  if (isLoading) return <div>Carregando filiais...</div>
  if (isError) {
    console.error('Erro ao carregar as filiais:', isError)
    return <div>Erro ao carregar filiais.</div>
  }

  return (
    <div className="p-6 space-y-6">
      <Link
        to="/clientes"
        className="text-xs text-primary flex items-center gap-1"
      >
        <MoveLeft size={12} /> Voltar
      </Link>

      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">{cliente?.nomeEmpresa}</h2>
        <Button onClick={() => setOpen(true)}>+ Adicionar Filial</Button>
      </div>

      <div className="overflow-x-auto bg-background border rounded-xl shadow-sm">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Empresa</TableHead>
              <TableHead>CNPJ/CPF</TableHead>
              <TableHead>Categoria</TableHead>
              <TableHead className="text-center">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filiais.length > 0 ? (
              filiais.map((f) => (
                <TableRow key={f._id}>
                  <TableCell>{f.nomeEmpresa}</TableCell>
                  <TableCell>{f.cnpjCpf || '–'}</TableCell>
                  <TableCell>{f.categoria || '–'}</TableCell>
                  <TableCell className="flex justify-center gap-2">
                    <Button
                      variant="outline"
                      onClick={() =>
                        navigate(`/clientes/${clienteId}/filiais/${f._id}/orcamento`)
                      }
                    >
                      Orçamentos
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={async () => {
                        if (window.confirm(`Excluir "${f.nomeEmpresa}"?`)) {
                          await delMutation.mutateAsync({
                            id: f._id,
                            clientePaiId: clienteId!
                          })
                          toast.success('Removido!')
                          refetch()
                        }
                      }}
                    >
                      <Trash className="w-4 h-4 text-red-600" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={4}
                  className="text-center"
                >
                  Nenhuma filial encontrada.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <ModalNovaFilial
        open={open}
        onOpenChange={(v) => {
          setOpen(v)
          if (!v) refetch()
        }}
        clientePaiId={clienteId!}
      />
    </div>
  )
}
