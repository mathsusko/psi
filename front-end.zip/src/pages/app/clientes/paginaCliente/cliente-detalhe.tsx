import React from 'react'
import { MoveLeft } from 'lucide-react'
import { Link, useParams } from 'react-router-dom'
import { useCliente } from '@/hooks/useCliente'

export default function ClienteDetalhe() {
  const { clienteId } = useParams<{ clienteId: string }>()
  const { data: cliente, isLoading, isError } = useCliente(clienteId!)

  if (isLoading) return <div>Carregando cliente...</div>
  if (isError || !cliente) return <div>Cliente não encontrado.</div>

  return (
    <div className="flex flex-col gap-6 p-4">
      {/* Breadcrumb / voltar */}
      <Link
        to="/clientes"
        className="flex items-center text-sm text-primary gap-1"
      >
        <MoveLeft size={16} /> Voltar para Clientes
      </Link>

      {/* Cabeçalho com nome do cliente */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{cliente.nomeEmpresa}</h1>
      </div>

      {/* Aqui estamos redirecionando para o perfil da filial */}
      {/* Isso será gerido no componente 'perfil-filial.tsx' agora */}
    </div>
  )
}
