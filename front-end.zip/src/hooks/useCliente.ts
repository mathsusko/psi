// src/hooks/useCliente.ts
import { useQuery } from '@tanstack/react-query'
import { ClientesService, Cliente } from '@/api/clientes'

export function useCliente(clienteId: string) {
  return useQuery<Cliente>(
    ['cliente', clienteId],
    () => ClientesService.buscarPorId(clienteId),
    { enabled: Boolean(clienteId) }
  )
}
