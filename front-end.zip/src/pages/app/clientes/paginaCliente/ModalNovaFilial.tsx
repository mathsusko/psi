import React, { useState, useEffect } from 'react'
import { useCriarFilial } from '@/hooks/useFiliais'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { toast } from 'sonner'
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogTitle,
  DialogDescription,
  DialogClose
} from '@radix-ui/react-dialog'
import { X } from 'lucide-react'

export function ModalNovaFilial({
  open,
  onOpenChange,
  clientePaiId
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
  clientePaiId: string
}) {
  const [nome, setNome] = useState('')
  const mutation = useCriarFilial()

  useEffect(() => {
    if (open) setNome('')
  }, [open])

  const handle = (e: React.FormEvent) => {
    e.preventDefault()
    if (!nome.trim()) {
      toast.error('Nome é obrigatório')
      return
    }
    mutation.mutate({ nomeEmpresa: nome.trim(), clientePaiId })
    onOpenChange(false)
  }

  return (
    <Dialog
      open={open}
      onOpenChange={onOpenChange}
    >
      <DialogTrigger asChild>{/* trigger moved to parent */}</DialogTrigger>
      <DialogContent className="max-w-md">
        <div className="flex justify-between items-center mb-2">
          <DialogTitle>Nova Filial</DialogTitle>
          <DialogClose asChild>
            <button aria-label="Fechar">
              <X className="w-5 h-5" />
            </button>
          </DialogClose>
        </div>
        <DialogDescription className="mb-4">Informe o nome da filial</DialogDescription>
        <form
          onSubmit={handle}
          className="space-y-4"
        >
          <Input
            placeholder="Nome da Filial"
            value={nome}
            onChange={(e) => setNome(e.target.value)}
            required
            disabled={mutation.isLoading}
          />
          <div className="flex justify-end gap-2">
            <Button
              type="button"
              variant="secondary"
              onClick={() => onOpenChange(false)}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={mutation.isLoading}
            >
              {mutation.isLoading ? 'Criando...' : 'Criar'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
