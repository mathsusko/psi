import { useParams } from 'react-router-dom'
import { useState } from 'react'
import { format } from 'date-fns'
import { toast } from 'sonner'
import { Trash } from 'lucide-react'

import { useFiliais } from '@/hooks/useFiliais'
import { useNotasFiscais, useDeletarNotaFiscal } from '@/hooks/useNotasFiscais'

import { ModalAdicionarNotaFiscal } from './ModalAdicionarNotaFiscal'
import { Button } from '@/components/ui/button'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@/components/ui/table'

export default function Documentos() {
  const { filialId } = useParams<{ filialId: string }>()
  const [open, setOpen] = useState(false)

  const {
    data: filial,
    isLoading: carregandoFilial,
    error: erroFilial
  } = useFiliais(filialId!)

  const {
    data: notas = [],
    isLoading: carregandoNotas,
    error: erroNotas
  } = useNotasFiscais(filialId!) // 🔥 Agora filtrando corretamente por filialId

  const { mutateAsync: deletarNota } = useDeletarNotaFiscal(filialId!) // 🔥 Passando o filialId para invalidar corretamente

  const handleDeletar = async (id: string) => {
    try {
      await deletarNota(id)
      toast.success('Nota fiscal removida.')
    } catch {
      toast.error('Erro ao remover nota fiscal.')
    }
  }

  if (carregandoFilial || carregandoNotas) {
    return <p className="p-6 text-sm text-muted-foreground">Carregando dados...</p>
  }

  if (erroFilial || erroNotas) {
    return (
      <p className="p-6 text-sm text-red-500">
        Erro ao carregar informações da filial ou notas fiscais.
      </p>
    )
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">
          Notas Fiscais Recebidas – {filial?.nomeEmpresa}
        </h2>
        <Button onClick={() => setOpen(true)}>+ Nova Nota</Button>
      </div>

      <div className="border rounded-xl overflow-x-auto shadow-sm">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Empresa</TableHead>
              <TableHead>Descrição</TableHead>
              <TableHead>Data Recebida</TableHead>
              <TableHead>Arquivo</TableHead>
              <TableHead>Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {notas.length > 0 ? (
              notas.map((nota) => (
                <TableRow key={nota._id}>
                  <TableCell>{nota.clienteNome}</TableCell>
                  <TableCell>{nota.descricao}</TableCell>
                  <TableCell>
                    {nota.dataRecebimento
                      ? format(new Date(nota.dataRecebimento), 'dd/MM/yyyy')
                      : '--'}
                  </TableCell>
                  <TableCell>
                    <a
                      href={`/uploads/${nota.caminhoArquivo}`}
                      download={nota.caminhoArquivo}
                      className="text-blue-600 underline text-sm"
                    >
                      Baixar PDF
                    </a>
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="icon"
                      title="Excluir nota fiscal"
                      onClick={() => handleDeletar(nota._id)}
                    >
                      <Trash className="w-4 h-4 text-red-600" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={5}
                  className="text-center text-muted-foreground py-4"
                >
                  Nenhuma nota fiscal cadastrada para esta filial.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <ModalAdicionarNotaFiscal
        open={open}
        onOpenChange={setOpen}
        filialId={filialId!} // 🔥 Agora só precisa do ID da filial
      />
    </div>
  )
}
